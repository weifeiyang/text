package week12;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Dao {
public ArrayList<Student>inputStident(){
	ArrayList<Student>ListStudent = new ArrayList<Student>();
	Scanner scan = new Scanner(System.in);
	String aLine="";
	while(!(aLine = scan.nextLine()).equals("end")) {
		String arr[] = aLine.split(",|��");
		String id = arr[0];
		String name = arr[1];
		String gender = arr[2];
		Student stu =new Student(id,name,gender);
		ListStudent.add(stu);
	}
	return ListStudent;
}
public ArrayList<Student> importStudentFromTxt(){
	ArrayList<Student>listStudent = new ArrayList<Student>();
	try {
		File file = new File("d:/Student.txt");
		FileReader fr = new FileReader(file);
		BufferedReader bf = new BufferedReader(fr);
		String aLine = "";
		while((aLine = bf.readLine()) != null) {
			String arr[] = aLine.split(",|��");
			String id = arr[0];
			String name = arr[1];
			String gender = arr[2];
			Student stu = new Student(id,name,gender);
			listStudent.add(stu);
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return listStudent;
}
public ArrayList<Course>inputCourse(){
	return null;
}
public ArrayList<Course>importCourseFromTxt(){
	ArrayList<Course>listCourse = new ArrayList<Course>();
	try {
		File file = new File("d:/Course,txt");
		FileReader fr = new FileReader(file);
		BufferedReader bf =new BufferedReader(fr);
		String aLine="";
		while((aLine=bf.readLine())!=null) {
			String arr[] = aLine.split(",|��");
			String id=arr[0];
			String name=arr[1];
			int Grade=arr[2].indexOf(arr[2]);
			Course stu = new Course(id,name,Grade);
			listCourse.add(stu);
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return null;
}
public void print(ArrayList<Student>listStudent,ArrayList<Result>listResult) {
	System.out.println("��ѧ��ͳ��");
	System.out.println("ѧ��\t����\t�Ա�\tƽ����");
	for(Student student : listStudent) {
		System.out.println(student.toString());
	}
}
public void writeTxt(ArrayList<Student>listStudent,ArrayList<Result>listResult) {
	File file = new File("d:/result.txt"); 
}

public ArrayList<Student>processByStudent(ArrayList<Student>listStudent,ArrayList<Course>listCourse){
	ArrayList<Student>list3=new ArrayList<Student>();
	for(Student stu:listStudent) {
		int count=0;
		float sum=0;
		String id=stu.getGender();
		for(Course course:listCourse) {
			if(id.equals(course.getId())) {
				sum+=course.getGrade();
				count++;
			}
		}
		float avg =sum/count;
		stu.setAvg(avg);
		list3.add(stu);
	}
	return list3;
}
}

