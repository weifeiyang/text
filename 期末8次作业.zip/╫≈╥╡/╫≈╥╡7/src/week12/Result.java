package week12;

public class Result {
	private String id;
	private String courseName;
	private String Avg;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getAvg() {
		return Avg;
	}
	public void setAvg(String avg) {
		Avg = avg;
	}
}
