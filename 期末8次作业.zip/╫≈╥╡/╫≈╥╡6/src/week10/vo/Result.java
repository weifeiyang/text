package week10.vo;

public class Result {
	private
	String province;
	String names;
	int count;
	
	public Result(String province, String names, int count) {
		this.province = province;
		this.names = names;
		this.count = count;
	}
	
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return province+"\t"+count+"��"+"("+names+")";
	}
}
