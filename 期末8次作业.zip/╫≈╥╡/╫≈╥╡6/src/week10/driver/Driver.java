package week10.driver;

import java.util.ArrayList;
import java.util.Scanner;
import week10.dao.*;
import week10.vo.Result;
import week10.vo.Student;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDao dao=new StudentDao();
		ArrayList<Student>stuList=dao.add();
		ArrayList<Result>resultList=dao.statis(stuList);
		dao.display(stuList, resultList);
	}														
}
