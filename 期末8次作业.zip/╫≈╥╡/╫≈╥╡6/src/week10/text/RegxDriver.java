package week10.text;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegxDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String regxMobile = "1[3578]\\d{9}";//�ƶ��绰
		//String regxMobile = "(0\\d{2,3}-?)?[1,9]\\{6,7}";//�̶��绰
		//String regxMobile ="\\w+@\\w(.\\w+)+";//��ַ
		String regxMobile ="\\d*+[+-x/]+\\d*";//��������
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		String phone="";
		Pattern p=Pattern.compile(regxMobile);
		Matcher m=p.matcher(phone);
		while(!m.matches()) {
			System.out.println("������");
		phone=scan.nextLine();
		p=Pattern.compile(regxMobile);
		m=p.matcher(phone);
		if(m.matches()) {
			System.out.println("����Ϸ�");
		break;}
		else {
			System.out.println("���벻�Ϸ�������������");
			phone=scan.nextLine();
		}}
	}


}
