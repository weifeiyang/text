package week10.dao;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import week10.vo.Result;
import week10.vo.Student;
public class StudentDao {
	public ArrayList<Student>add(){
		ArrayList<Student>list=new ArrayList<Student>();
		Scanner scan=new Scanner(System.in);
		String date="";
		while(!(date=scan.nextLine()).equals("end")) {
			String stuArray[]=date.split(",|��");
			Student student = new Student(stuArray[0],stuArray[1],stuArray[2],stuArray[3]);
			list.add(student);
		}
	return list;
	}
	
	
	public ArrayList<Result>statis(ArrayList<Student>list){
		ArrayList<Result> listResult=new ArrayList<Result>();
		for(int i=0;i<list.size();i++) {
			Student stu=list.get(i);
			String province=stu.getProvince();
			String name=stu.getName();
			int index = query(listResult,province);
			if(index!=-1) {//����
				Result oldResult=listResult.get(index);
				oldResult.setCount(oldResult.getCount()+1);
				oldResult.setNames(oldResult.getNames()+","+name);
				listResult.set(index, oldResult);
				
			}else {
				Result newResult=new Result(province,name,1);
				listResult.add(newResult);
			}
		}
	
		
		return listResult;
	}
	
	
	public int count(ArrayList<Result> listResult) //������
	{
		int num=listResult.size();
		return num;
	}
	
	
	public int countByGender(ArrayList<Student> StuList,String gender) //�Ա�����
	{
		int num=0;
		for (Student student : StuList) {
			String stuGender=student.getGender();
			if(stuGender.equals(gender)) {
				num++;
			}
		}
		return num;
	}
	
	
	public int query(ArrayList<Result> listResult,String province) //ʡ������
	{
		int num=-1;
		for(int i=0;i<listResult.size();i++) {
			Result result=listResult.get(i);
			if(result.getProvince().equals(province)) {
				return i;
			}
		}
		return num;
	}
	public void display(ArrayList<Student>stulist,ArrayList<Result> listResult) {
		int total=stulist.size();
		int maleNum=countByGender(stulist,"��");
		int femaleNum=countByGender(stulist,"Ů");
		System.out.println("��������"+total);
		System.out.println("������"+maleNum+"�ˣ�"+"Ů"+femaleNum+"��");
		System.out.println("ѧ����������ʡ��");
		for (Result result : listResult) {
			System.out.println(result.toString());
		}
	}
}
