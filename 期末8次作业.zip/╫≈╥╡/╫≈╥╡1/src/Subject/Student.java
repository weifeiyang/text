package Subject;

public class Student {
	private String studentId;
	private String Name;
	public Student(String studentId,String Name) {
		this.studentId=studentId;
		this.Name=Name;
		
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	@Override
	public String toString() {
		return studentId+"\t"+Name;
	}
	
}
