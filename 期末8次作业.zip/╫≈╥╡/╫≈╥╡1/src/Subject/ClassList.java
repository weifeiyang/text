package Subject;

public class ClassList {
	private String semester;
	private String year;
	private Subject subj;
	private Student s1;
	private Student s2;
	public ClassList(String semester,String year,Subject subj,Student s1,Student s2) {
		this.semester=semester;
		this.year=year;
		this.subj=subj;
		this.s1=s1;
		this.s2=s2;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public Subject getSubj() {
		return subj;
	}
	public void setSubj(Subject subj) {
		this.subj = subj;
	}
	public Student getS1() {
		return s1;
	}
	public void setS1(Student s1) {
		this.s1 = s1;
	}
	public Student getS2() {
		return s2;
	}
	public void setS2(Student s2) {
		this.s2 = s2;
	}
	public String toString() {
		String info="";
		info = year+"ѧ��"+semester+"ѧ��"+"\n";
		info += "============================="+"\n";
		info += subj.toString()+"\n";
		info += "ѧ��\t����"+"\n";
		info += s1.toString()+"\n";
		info += s2.toString()+"\n";
				
		return info;
	}
}
