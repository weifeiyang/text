package Subject;

public class Subject {
	private String subjectId;
	private String subjectName;
	public Subject(String subjectId,String subjectName) {
		this.subjectId=subjectId;
		this.subjectName=subjectName;
	}
	@Override
	public String toString() {
		return "�γ̱��"+subjectId+"\t"+"�γ���"+subjectName;
	}

}
