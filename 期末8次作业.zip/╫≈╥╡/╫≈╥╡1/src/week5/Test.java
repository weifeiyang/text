package week5;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String date,month,year,day;
		int pos1,pos2;//�������ŵ�λ��
		Scanner scan = new Scanner(System.in);
		date = scan.next();
		pos1=date.indexOf('-');
		pos2=date.indexOf('-', pos1+1);
		year = date.substring(0, pos1);
		month = date.substring(pos1+1,pos2 );
		day = date.substring(pos2+1);
		System.out.println(year+"��"+month+"��"+day+"��");
			
	}

}
