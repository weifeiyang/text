package Employee;

public class Employee {
	private String id;
	private String name;
	private String part;
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	private double baseSalary;
	public Employee() {
		
	}
	public Employee(String id,String name,String part,double baseSalary) {
		this.id=id;
		this.name=name;
		this.part=part;
		this.baseSalary=baseSalary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}
	public void updateBaseSalary() {
		this.baseSalary=baseSalary*(1+0.35);
	}

}
