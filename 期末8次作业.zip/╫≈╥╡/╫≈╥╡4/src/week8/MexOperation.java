package week8;

import java.util.Scanner;

public class MexOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		String express = scan.next();
		int a=0,len=express.length();
		float b=0,c=0;
		a=express.indexOf("+");
		System.out.println(express.substring(0, a));
		b=Float.parseFloat(express.substring(0, a));
		c=Float.parseFloat(express.substring(a+1, len));
		System.out.println(b+"+"+c+"="+(b+c));
	}

}
