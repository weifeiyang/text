package week11;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Express {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("���������ʽ��");
		Scanner scan = new Scanner(System.in);	
		String express=scan.next();
		String regex="((add)|(sub)|(max)|(min)|(doubleMe))\\(\\d{1,}(,\\d{1,})?\\)";
		Pattern p = Pattern.compile(regex);
		Matcher m=p.matcher(express);
		String result=express;
		while(m.find()) {
			String basicExpress = m.group();
			String s = cal(basicExpress);
			basicExpress=basicExpress.replaceAll("\\(", "\\\\(");
			basicExpress=basicExpress.replaceAll("\\)", "\\\\)");
			System.out.println("�滻ǰ"+result);
			result = result.replaceAll(basicExpress, s);
			System.out.println("�滻��"+result);
			m=p.matcher(result);
		}
		System.out.println("�����"+express+"="+result);
	}
	public static String cal(String express) {
		String result = "";
		String code=express.substring(0,express.indexOf("("));
		int iResult = 0;
		if(code.equals("doubleMe")) {
			String sFirst = express.substring(express.indexOf("(")+1,express.indexOf(")"));
			int first = Integer.parseInt(sFirst);
			iResult = first*2;
		}
		else {
			String sFirst=express.substring(express.indexOf("(")+1,express.indexOf(","));
			String sSecond=express.substring(express.indexOf(",")+1,express.indexOf(")"));
			int first = Integer.parseInt(sFirst);
			int second = Integer.parseInt(sSecond);
			if(code.equals("add")) {
				iResult=first+second;
			}
			if(code.equals("sub")) {
				iResult=first-second;
			}
			if(code.equals("max")) {
				if(first>second) {
					iResult=first;
				}
				else
					iResult=second;
			}
			if(code.equals("min")) {
				if(first<second) {
					iResult=first;
				}
				else
					iResult=second;
			}
		}
		result=String.valueOf(iResult);
		return result;
	}
}
