package FIleTest;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
public class test {
	public static void main(String[] args) {
		try {
			String fileName="D:/a.txt";
			//1.��ˮ��
			File aFile  = new File(fileName);
			//2.װˮ��
			FileReader fr = new FileReader(aFile);
			//3.װˮ��ͷ
			BufferedReader bf = new BufferedReader(fr);
			//4.��ˮ��ͷ
			String aLine="";
			int result;
			while((aLine=bf.readLine())!=null) {
				System.out.println(aLine);
				
			}
			
			File ofl = new File("D:/a.txt");
			FileWriter fwt = new FileWriter(ofl);
			PrintWriter pwt = new PrintWriter(fwt);
			pwt.println("0000");
			pwt.close();
			bf.close();
			fr.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
