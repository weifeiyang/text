package Employee;

public class salePerson extends Employee{
	private double yearSalary;
	public salePerson() {
		super();
	}
	public salePerson(String id,String name,String part,double baseSalary,double yearSalary) {
		super(id,name,part,baseSalary);
		this.yearSalary=yearSalary;
	}

	public double getYearSalary() {
		return yearSalary;
	}

	public void setYearSalary(double yearSalary) {
		this.yearSalary = yearSalary;
	}
	public void updateSalary() {
		this.setBaseSalary(this.getBaseSalary()*1.0725+this.yearSalary*0.1);
	}
	public String toString() {
		String info="";
		info=super.toString();
		info+=",yearSalary:"+this.yearSalary+",����:"+super.getBaseSalary();
		return info;
	}
}
