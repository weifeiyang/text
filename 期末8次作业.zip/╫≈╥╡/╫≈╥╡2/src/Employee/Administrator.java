package Employee;

public class Administrator extends Employee{
	private double bonous;
	public Administrator() {
		super();
	}
	public Administrator(String id,String name,String part,double baseSalary,double bonous) {
		super.setId(id);
		super.setName(name);
		super.setPart(part);
		super.setBaseSalary(baseSalary);
		this.bonous=bonous;
	}
	public double getBonous() {
		return bonous;
	}

	public void setBonous(double bonous) {
		this.bonous = bonous;
	}
	public void updateSalary() {
		this.setBaseSalary(this.getBaseSalary()*1.2+bonous);
	}
	public String toString() {
		String info="";
		info=super.toString();
		info+=",bonous"+this.bonous+",����:"+super.getBaseSalary();
		return info;
		
	}
	
}
