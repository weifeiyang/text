package Student;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stu1=new Student("1005","john");
		Student stu2=new Student("1006","tom");
		Student stu3=new Student("1007","mike");
		StudentList list=new StudentList(10);
		list.add(stu1);
		list.add(stu2);
		list.add(stu3);
		System.out.println(list.toString());
		list.remove(1);
		System.out.println(list.toString());
		list.remove(4);
		if(list.found(stu1)==-1)
			System.out.println("not found");
		else
			System.out.println(stu1.toString());
		if(list.found(stu2)==-1)
			System.out.println("not found");
		else
			System.out.println(stu2.toString());
		if(list.found(stu3)==-1)
			System.out.println("not found");
		else
			System.out.println(stu3.toString());
		if(list.indexOf("1005")==-1)
			System.out.println("not found");
		else
			System.out.println(list.get(list.indexOf("1005")).toString());
	}

}
