package Subject;

public class Subject {
	private
	String subjectId;
	String subjectName;
	String systerm;
	String year;
	int arrayOfStudent;
	public Subject( String subjectId, String subjectName, String systerm, String year,
			int arrayOfStudent) {
		super();
		this.subjectId = subjectId;
		this.subjectName = subjectName;
		this.systerm = systerm;
		this.year = year;
		this.arrayOfStudent = arrayOfStudent;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getSysterm() {
		return systerm;
	}
	public void setSysterm(String systerm) {
		this.systerm = systerm;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public int getArrayOfStudent() {
		return arrayOfStudent;
	}
	public void setArrayOfStudent(int arrayOfStudent) {
		this.arrayOfStudent = arrayOfStudent;
	}

	
}
