package Goods;

import java.util.ArrayList;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductDao dao = new ProductDao();
		ArrayList<week9.Goods>list =dao.inputFromKeyBoard();
		Result result = dao.process(list);
		dao.output(list, result);
	}

}
